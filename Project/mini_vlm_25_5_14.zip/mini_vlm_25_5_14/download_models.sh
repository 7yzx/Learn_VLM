modelscope download --model Qwen/Qwen2.5-VL-7B-Instruct --local_dir 'models/qwen2.5vl'

git clone https://huggingface.co/vidore/colqwen2-v1.0 models/colqwen2-v1.0
git clone https://huggingface.co/vidore/colqwen2-base models/colqwen2-base

git clone https://huggingface.co/lightonai/MonoQwen2-VL-v0.1 models/MonoQwen2-VL-v0.1