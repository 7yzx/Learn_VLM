# 下载微调数据集
modelscope download --dataset 'swift/ChartQA' --local_dir 'data/sft'

# 下载mrag数据集
git clone https://huggingface.co/datasets/gigant/pdfvqa data/mrag

